//
// Created by jj on 2/25/19.
//

#ifndef PROCGEN_PROCGEN_H
#define PROCGEN_PROCGEN_H
int newProcCounter;
int new_process();
#endif //PROCGEN_PROCGEN_H
