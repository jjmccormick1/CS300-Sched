//
// Created by jj on 2/10/19.
//

#ifndef SCHED_SCHED_H
#define SCHED_SCHED_H

typedef struct node node;

#endif //SCHED_SCHED_H
